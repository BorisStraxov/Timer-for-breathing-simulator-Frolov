package com.example.goshany.myapplicationtimingchain;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.Timer;

public class MainActivityTimigChain extends AppCompatActivity {
    int inTimepda;
    int inTimevdox;
    int inTimevydox;
    int inTimetrenirovka;
    int inPorcVydox;
    int inTimevydoxPodg;
    int inCekunda;
    long timeWhenStopped;
    long proshloMillis;
    long proshloMillisVdox;
    long proshloMillisVydox;
    long proshloMillisVydoxPodg;
    long proshloMillisCekunda;
    long proshloMillisPDA=10;
    int MILLIS_PER_SECOND = 1000;
    int VYDOX_OUTPUT_FONT;
    int GASITEL_FONT;
    int inFinichVdox;
    long sekUntilFinishedVdox;
    long sekUntilFinishedVydox;
    int inKolichestoSemerok;
    int inVydoxOstatok;
    int myWidthDisplay;
    int myHeightDisplay;

    Chronometer Mchronometer;

     MediaPlayer   mediaPlayer = null;

    Timer moytimerforVdox = new Timer();
    Timer moytimerforVydox = new Timer();
    Timer moytimerforVydoxPodg = new Timer();


    ToggleButton tgPVydox;
    CountDownTimer myCountDownTimer;
    CountDownTimer myCountDownTimerVdox;
    CountDownTimer myCountDownTimerVydox;
    CountDownTimer myCountDownTimerVydoxPodg;

    EditText mT_PDA;
    EditText mT_Vdox;
    EditText mT_VydoxPodg;
    EditText mT_Trenirovka;

    TextView PorcVdox;

    TextView textview_vremyVdoxa;
    TextView textview_vremyVydox;
    TextView textview_vremyVydoxPodg;


    Button minus_PDA;
    Button plus_PDA;
    Button minus_Vdox;
    Button plus_Vdox;
    Button minus_Vydox;
    Button plus_Vydox;
    Button minus_Trenirovka;
    Button plus_Trenirovka;
    Button Start;
    Button Pauza;
    Button Stop;

    TimeUpDown TimeUpDownPda = new TimeUpDown();
    TimeUpDown TimeUpDownVdox = new TimeUpDown();
    TimeUpDown TimeUpDownVydox = new TimeUpDown();
    TimeUpDown TimeUpDownTrenirovka = new TimeUpDown();
    ButtonSPS ButtonSPSsTart = new ButtonSPS();
    ButtonSPS ButtonSPSpAuza = new ButtonSPS();
    ButtonSPS ButtonSPSsTop = new ButtonSPS();
    MnogoChronometrov ChronometrTime = new MnogoChronometrov();


    MoyCountDownTimer MoyCountDownTimerRabota = new MoyCountDownTimer();
    MoyVykliuchatel MoyTimerVykl = new MoyVykliuchatel();
    MoyMediaPlayer MyMP3player = new MoyMediaPlayer();
    Raschety RaschetyVydox = new Raschety();
   // Display display = getWindowManager().getDefaultDisplay();
    DisplayMetrics metricsB = new DisplayMetrics();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_timig_chain);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mT_PDA = (EditText) findViewById(R.id.editText_timePDA);
        mT_Vdox = (EditText) findViewById(R.id.editText_TimeVdox);
        mT_VydoxPodg = (EditText) findViewById(R.id.editText_TimeVydoxPodg);
        mT_Trenirovka = (EditText) findViewById(R.id.editText_TimeTrenirovka);


        PorcVdox = (TextView) findViewById(R.id.textView_PorcVdox);

        minus_PDA = (Button) findViewById(R.id.button_minus_PDA);
        plus_PDA = (Button) findViewById(R.id.button_plusPDA);
        minus_Vdox = (Button) findViewById(R.id.button_minusVdox);
        plus_Vdox = (Button) findViewById(R.id.button_plusVdox);
        minus_Vydox = (Button) findViewById(R.id.button_minusVydox);
        plus_Vydox = (Button) findViewById(R.id.button_plusVydox);
        minus_Trenirovka = (Button) findViewById(R.id.button_minusTrenirovka);
        plus_Trenirovka = (Button) findViewById(R.id.button_plusTrenirovka);
        Start = (Button) findViewById(R.id.button_Start);
        Pauza = (Button) findViewById(R.id.button_Pauza);
        Stop = (Button) findViewById(R.id.button_STOP);
        tgPVydox = (ToggleButton) findViewById(R.id.toggleButton);
        Mchronometer = (Chronometer) findViewById(R.id.chronometer);


        textview_vremyVdoxa = (TextView) findViewById(R.id.vremyvdoxa);
        textview_vremyVydox = (TextView) findViewById(R.id.textViewVydox);
        textview_vremyVydoxPodg = (TextView) findViewById(R.id.textViewVydoxPodg);


        mT_PDA.setText(Integer.toString(inTimepda = 7));
        mT_Vdox.setText(Integer.toString(inTimevdox = 2));
        mT_VydoxPodg.setText(Integer.toString(inTimevydoxPodg = 2));
        mT_Trenirovka.setText(Integer.toString(inTimetrenirovka = 12));
        inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;

       // determineSizeDisplay();
        TimeUpDownPda.ustanovkaTimepda(mT_PDA, minus_PDA, plus_PDA);
        TimeUpDownVdox.ustanovkaTimevdox(mT_Vdox, minus_Vdox, plus_Vdox);
        TimeUpDownVydox.ustanovkaTimevydoxPodg(mT_VydoxPodg, minus_Vydox, plus_Vydox);
        TimeUpDownTrenirovka.ustanovkaTimetrenirovka(mT_Trenirovka, minus_Trenirovka, plus_Trenirovka);
        vklychitPorcVydox();
        ButtonSPSsTart.sTart(Start);
        ButtonSPSpAuza.pAuza(Pauza);
        ButtonSPSsTop.sTop(Stop);




    }//end onCread


    public  void determineSizeDisplay(){
// узнаем размеры экрана из класса Display
        Display display = getWindowManager().getDefaultDisplay();
     //   DisplayMetrics metricsB = new DisplayMetrics();
        display.getMetrics(metricsB);
        myWidthDisplay = metricsB.widthPixels;
        myHeightDisplay =metricsB.heightPixels;
        if (myWidthDisplay>=200 && myWidthDisplay<600){VYDOX_OUTPUT_FONT = 75;GASITEL_FONT = 25;}
        if (myWidthDisplay>=600){VYDOX_OUTPUT_FONT = 190;GASITEL_FONT = 38;}

    }

    public class Raschety {


        public void raschitatVydoxSemerok() {

            // inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
            inKolichestoSemerok = inTimevydox / 7;
            inVydoxOstatok = inTimevydox % 7;

            if (inVydoxOstatok == 0) {
                inKolichestoSemerok -= 1;
                inVydoxOstatok = 7;

            }
            if (inVydoxOstatok == 1) {
                inKolichestoSemerok -= 1;
                inVydoxOstatok = 8;

            }
            if (inVydoxOstatok == 2) {
                inKolichestoSemerok -= 1;
                inVydoxOstatok = 9;

            }
            if (inVydoxOstatok == 3) {
                inKolichestoSemerok -= 1;
                inVydoxOstatok = 10;

            }


        }



    }



    public  class MoyMediaPlayer {

        public void myMediaPlayerStapt (int zvuk ) {
            switch (zvuk){
                case 1: mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.vdox2sec); break;
                case 2: mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.vydox3secmin);break;
                case 3:mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.vydoxpodg2sec);break;
                case 4:mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.vydox20sek);break;
                case 5:mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.tiktak1sek);break;
                case 6:mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.vydox6sek);break;
                case 7:mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.vydox6sek_tiktak1sek);break;
                //mediaPlayer = MediaPlayer.create(this, R.raw.vydox20sek);
                default: ; break;
            }
            mediaPlayer.start();

        }

        public void myMediaPlayerStop(){
            mediaPlayer.stop();
            mediaPlayer.release(); mediaPlayer = null;

        }



    }

    //=====================================================================================
    public void  vkliuchalka() {
        determineSizeDisplay();
      //  vklychitPorcVydox();
        MoyCountDownTimerRabota.sekundoSchetVdox(inTimevdox, textview_vremyVdoxa, (Long.toString(inTimevdox)));



    }
//=============================================================================================



    public class MoyVykliuchatel extends  Activity{

        public void gasitelCDT(){
            //  myCountDownTimerVdox = null;
            myCountDownTimerVdox.cancel();
            textview_vremyVdoxa.setTextSize(GASITEL_FONT);
            textview_vremyVdoxa.setText("Вдох");
            //  myCountDownTimerVydox = null;
            myCountDownTimerVydox.cancel();
            textview_vremyVydox.setTextSize(GASITEL_FONT);
            textview_vremyVydox.setText("Выдох");
            //  myCountDownTimerVydoxPodg = null;
            myCountDownTimerVydoxPodg.cancel();
            textview_vremyVydoxPodg.setTextSize(GASITEL_FONT);
            textview_vremyVydoxPodg.setText("ВыдохП");

        }


    }


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public  class MoyCountDownTimer extends Activity {
        public void sekundoSchetVdox(final int maxTime1, final TextView Vokno1, final String strOkno1) {
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;

                    myCountDownTimerVdox = new CountDownTimer(maxTime1 * 1000, MILLIS_PER_SECOND) {
                        @Override
                        public void onTick(long millisUntilFinishedVdox) {
                            sekUntilFinishedVdox = millisUntilFinishedVdox / 1000;
                            Vokno1.setTextSize(VYDOX_OUTPUT_FONT);
                            Vokno1.setText(Long.toString(sekUntilFinishedVdox));

                            textview_vremyVdoxa.setBackgroundResource(R.color.redColor);

                        }

                        public void onFinish() {
                            Vokno1.setTextSize(38);
                            Vokno1.setText(strOkno1);

                            textview_vremyVdoxa.setBackgroundResource(R.color.Teal);
                         MoyCountDownTimerRabota.sekundoSchetVydox();

                        }
                    }.start();
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                    MyMP3player.myMediaPlayerStapt(1);
        }

 //--------------------------------------------------------------------------------------------------
        public void sekundoSchetVydox() {
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
           // vklychitPorcVydox();
            RaschetyVydox.raschitatVydoxSemerok();

            mediaPlayer.release();
                    myCountDownTimerVydox = new CountDownTimer(inTimevydox * 1000, MILLIS_PER_SECOND) {

                       @Override
                        public void onTick(long millisUntilFinishedVydox) {
                         //  RaschetyVydox.raschitatVydoxSemerok();
                           textview_vremyVydox.setTextSize(VYDOX_OUTPUT_FONT);
                            long sekUntilFinishedVydox = millisUntilFinishedVydox / 1000;
      //##############################################################################################
                           if (inPorcVydox == 10) {

                             if (inKolichestoSemerok == 1) //пда с 15
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 2)                  //пда с 22
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 3)   //пда с 29
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 4)     //пда с 36
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 5)     //пда с 43
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                                                         }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 6)     //пда с 50
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                      }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 7)     //пда с 57
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 8)     //пда с 64
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                                                         }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 9)     //пда с 71
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                                                         }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 10)     //пда с 78
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 69) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 70) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 71) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 11)     //пда с 85
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 69) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 70) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 71) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 76) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 77) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 78) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 12)     //пда с 92
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 69) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 70) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 71) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 76) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 77) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 78) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 83) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 84) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 85) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }

                               if (inKolichestoSemerok == 13)     //пда с 99
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 69) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 70) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 71) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 76) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 77) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 78) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 83) {
                                   textview_vremyVydox.setBackgroundResource(R.color.redColor);
                               }
                                   if (sekUntilFinishedVydox == inTimevydox - 84) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 85) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 90) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 91) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 92) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 14)     //пда с 106
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 69) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 70) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 71) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 76) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 77) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 78) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 83) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 84) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 85) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 90) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 91) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 92) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                      }
                                   if (sekUntilFinishedVydox == inTimevydox - 97) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 98) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 99) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 15)     //пда с 113
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 69) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 70) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 71) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 76) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 77) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 78) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 83) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 84) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 85) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 90) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 91) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 92) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 97) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 98) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 99) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       }
                                   if (sekUntilFinishedVydox == inTimevydox - 104) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 105) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 106) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }
                               if (inKolichestoSemerok == 16)     //пда с 120
                               {
                                   if (sekUntilFinishedVydox == inTimevydox - 6) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 7) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 8) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 13) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 14) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 15) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 20) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 21) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 22) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 27) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 28) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 29) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 34) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 35) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 36) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 41) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 42) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 43) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 48) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 49) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 50) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 55) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 56) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 57) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 62) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 63) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 64) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 69) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 70) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 71) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 76) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 77) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 78) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);

                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 83) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 84) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 85) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 90) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 91) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 92) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 97) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 98) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 99) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 104) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 105) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 106) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                                                          }
                                   if (sekUntilFinishedVydox == inTimevydox - 111) {
                                       textview_vremyVydox.setBackgroundResource(R.color.redColor);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 112) {
                                       textview_vremyVydox.setBackgroundResource(R.color.colorblue);
                                   }
                                   if (sekUntilFinishedVydox == inTimevydox - 113) {
                                       textview_vremyVydox.setBackgroundResource(R.color.Teal);
                                       MyMP3player.myMediaPlayerStop();
                                       MyMP3player.myMediaPlayerStapt(4);
                                   }
                               }

                           }// если inPorcVydox = 10
                          // textview_vremyVydox.setBackgroundResource(R.color.redColor);
                            textview_vremyVydox.setText(Long.toString(sekUntilFinishedVydox));

                        }

                        public void onFinish() {
                            textview_vremyVydox.setTextSize(38);
                            textview_vremyVydox.setText((Long.toString(inTimevydox)));
                            textview_vremyVydox.setBackgroundResource(R.color.Teal);
                            MoyCountDownTimerRabota.sekundoSchetVydoxPodg(inTimevydoxPodg, textview_vremyVydoxPodg,  (Long.toString(inTimevydoxPodg)));
                           // myCountDownTimerVydox.cancel();
                        }
                    }.start();
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
            if (inPorcVydox == 10 && inKolichestoSemerok<=555) {
                MyMP3player.myMediaPlayerStapt(7);
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                    public void onCompletion(MediaPlayer arg0) {
                        arg0.start();//Запускаем воспроизведение заново
                    }

                });
            }
            else{
                MyMP3player.myMediaPlayerStapt(4);
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                    public void onCompletion(MediaPlayer arg0) {
                        arg0.start();//Запускаем воспроизведение заново
                    }

                });
            }

        }


        public void sekundoSchetVydoxPodg(final int maxTime3, final TextView Vokno3, final String strOkno3) {
            inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
            mediaPlayer.release();


                    myCountDownTimerVydoxPodg = new CountDownTimer(maxTime3*1000, MILLIS_PER_SECOND) {

                        @Override

                        public void onTick(long millisUntilFinishedVydoxPodg) {
                            long sekUntilFinishedVydoxPodg = millisUntilFinishedVydoxPodg / 1000;
                            Vokno3.setTextSize(VYDOX_OUTPUT_FONT);
                            Vokno3.setText(Long.toString( sekUntilFinishedVydoxPodg));
                            textview_vremyVydoxPodg.setBackgroundResource(R.color.redColor);
                            }

                        public void onFinish() {
                            Vokno3.setText(strOkno3);
                            Vokno3.setTextSize(38);
                            textview_vremyVydoxPodg.setBackgroundResource(R.color.Teal);
                            if      (proshloMillis > 0) {
                                MoyCountDownTimerRabota.sekundoSchetVdox(inTimevdox, textview_vremyVdoxa,  (Long.toString(inTimevdox)));
                            }
                            else{ myCountDownTimerVdox.cancel();
                              //  MyMP3player.myMediaPlayerStop();
                                //MoyTimerVykl.gasitelCDT();

                            }

                        }
                    }.start();
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                    MyMP3player.myMediaPlayerStapt(3);




        }

    }

    //____________====================+++++++++++++++++++++++++++++++++++++++++++++++

    public void sekundoSchet(int maxTime, final TextView Vokno, final String strOkno) {

        //int MILLIS_PER_SECOND = 1000;

        myCountDownTimer = new CountDownTimer(maxTime*1000, 1000) {

            @Override

            public void onTick(long millisUntilFinished) {

                Vokno.setText("" + millisUntilFinished/ 1000);
                //(Long.toString( millisUntilFinished / 1000));

            }

            public void onFinish() {
                Vokno.setText(strOkno);
            }
        }.start();

    }


    public class ButtonSPS extends Activity {
        public void sTart(Button Start1) {


            ChronometrTime.mYChronometer();
            Start1.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View view) {

                    Mchronometer.setBase(SystemClock.elapsedRealtime()
                            + timeWhenStopped);
                    Mchronometer.start();
                    // myCountDownTimerVdox.start();
                    vkliuchalka();

                }
            });



        }

        public void pAuza(Button Pauza1) {
            // mYChronometer();

            Pauza1.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    timeWhenStopped = Mchronometer.getBase() - SystemClock.elapsedRealtime();
                    Mchronometer.stop();
                    MoyTimerVykl.gasitelCDT();
                    MyMP3player.myMediaPlayerStop();

                }
            });
        }

        public void sTop(Button Stop1) {
            // mYChronometer();
            Stop1.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    Mchronometer.setBase(SystemClock.elapsedRealtime());
                    Mchronometer.stop();
                    timeWhenStopped = 0;
                    MoyTimerVykl.gasitelCDT();
                    MyMP3player.myMediaPlayerStop();


                }
            });
        }


    }//endButtons

    public class MnogoChronometrov extends Activity {

        public void mYChronometer() {
            Mchronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
                @Override
                public void onChronometerTick(Chronometer chronometer) {
                    proshloMillis = (SystemClock.elapsedRealtime() - Mchronometer.getBase()) / 1000;
                    //String stproshloMillis = proshloMillis/1000+"";
                    // int inproshloMillis = Integer.parseInt(stproshloMillis);

                    if (proshloMillis <= inTimetrenirovka * 60) {
                        PorcVdox.setText(Long.toString(proshloMillis));

                        //   ChronometerVdox.start();

                    } else {
                        Mchronometer.setBase(SystemClock.elapsedRealtime());
                        PorcVdox.setText("--ВСЁ! Вы молодец! Вы сделали это!--");
                        Mchronometer.stop();
                        timeWhenStopped = 0;
                      //  MyMP3player.myMediaPlayerStop();
                       // MoyTimerVykl.gasitelCDT();
                    }

                }
            });
        }



    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public class TimeUpDown extends Activity {

        public void ustanovkaTimepda(final EditText mT, Button minus, Button plus) {

            mT.setOnKeyListener(new View.OnKeyListener() {
                                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                                        if (event.getAction() == KeyEvent.ACTION_DOWN &&
                                                (keyCode == KeyEvent.KEYCODE_ENTER)) {
                                            // сохраняем текст, введенный до нажатия Enter в переменную

                                            inTimepda = Integer.parseInt(mT.getText().toString());

                                            switch (inTimepda){
                                                case 0: inTimepda=inTimepda+7;break;
                                                case 1: inTimepda=inTimepda+6;break;
                                                case 2: inTimepda=inTimepda+5;break;
                                                case 3: inTimepda=inTimepda+4;break;
                                                case 4: inTimepda=inTimepda+3;break;
                                                case 5: inTimepda=inTimepda+2;break;
                                                case 6: inTimepda=inTimepda+1;break;
                                                case 7: inTimepda=inTimepda+0;break;
                                                default: break;
                                            }
                                            mT.setText(Integer.toString(inTimepda));
                                            inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                                            return true;

                                        }
                                        return false;

                                    }


                                }

            );


            minus.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    inTimepda--;
                    if (inTimepda < 7) {
                        inTimepda++;
                    }
                    mT.setText(Integer.toString(inTimepda));
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                }

            });


            //-------------------------------------------------------------


            plus.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    inTimepda++;
                    mT.setText(Integer.toString(inTimepda));
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                }
            });

        }

        //========================================================================
        public void ustanovkaTimevdox(final EditText mT, Button minus, Button plus) {

            mT.setOnKeyListener(new View.OnKeyListener() {
                                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                                        if (event.getAction() == KeyEvent.ACTION_DOWN &&
                                                (keyCode == KeyEvent.KEYCODE_ENTER)) {
                                            // сохраняем текст, введенный до нажатия Enter в переменную
                                            inTimevdox = Integer.parseInt(mT.getText().toString());
                                            if (inTimevdox < 1) {
                                                inTimevdox = 1;
                                                mT.setText(Integer.toString(inTimevdox));
                                            }
                                            if (inTimevdox > 3) {
                                                inTimevdox = 3;
                                                mT.setText(Integer.toString(inTimevdox));
                                            }
                                            inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                                            return true;
                                        }
                                        return false;
                                    }
                                }
            );

            minus.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    inTimevdox--;
                    if (inTimevdox < 1) {
                        inTimevdox++;
                    }
                    mT.setText(Integer.toString(inTimevdox));
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                }
            });

            //-------------------------------------------------------------


            plus.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    inTimevdox++;
                    if (inTimevdox > 3) {
                        inTimevdox--;
                    }
                    mT.setText(Integer.toString(inTimevdox));
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                }
            });
        }
        //============================================================================
        public void ustanovkaTimevydoxPodg(final EditText mT, Button minus, Button plus) {

            mT.setOnKeyListener(new View.OnKeyListener() {
                                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                                        if (event.getAction() == KeyEvent.ACTION_DOWN &&
                                                (keyCode == KeyEvent.KEYCODE_ENTER)) {
                                            // сохраняем текст, введенный до нажатия Enter в переменную
                                            inTimevydoxPodg = Integer.parseInt(mT.getText().toString());
                                            if (inTimevydoxPodg > 4) {
                                                inTimevydoxPodg = 4;
                                                mT.setText(Integer.toString(inTimevydoxPodg));
                                            }
                                            inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                                            return true;
                                        }
                                        return false;
                                    }
                                }
            );


            minus.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    inTimevydoxPodg--;
                    if (inTimevydoxPodg < 0) {
                        inTimevydoxPodg++;
                    }
                    mT.setText(Integer.toString(inTimevydoxPodg));
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                }
            });

            //-------------------------------------------------------------
            plus.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    inTimevydoxPodg++;
                    if (inTimevydoxPodg > 4) {
                        inTimevydoxPodg--;
                    }
                    mT.setText(Integer.toString(inTimevydoxPodg));
                    inTimevydox = inTimepda - inTimevdox -inTimevydoxPodg;
                }
            });
        }
        //=============================================================================================
        public void ustanovkaTimetrenirovka(final EditText mT, Button minus, Button plus) {

            mT.setOnKeyListener(new View.OnKeyListener() {
                                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                                        if (event.getAction() == KeyEvent.ACTION_DOWN &&
                                                (keyCode == KeyEvent.KEYCODE_ENTER)) {
                                            // сохраняем текст, введенный до нажатия Enter в переменную
                                            inTimetrenirovka = Integer.parseInt(mT.getText().toString());
                                            if (inTimetrenirovka == 0) inTimetrenirovka = inTimetrenirovka + 1;
                                            mT.setText(Integer.toString(inTimetrenirovka));
                                            return true;
                                        }
                                        return false;
                                    }
                                }
            );
            minus.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    inTimetrenirovka--;
                    if (inTimetrenirovka < 1) {
                        inTimetrenirovka++;
                    }
                    mT.setText(Integer.toString(inTimetrenirovka));
                }
            });
            //-------------------------------------------------------------
            plus.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    inTimetrenirovka++;
                    mT.setText(Integer.toString(inTimetrenirovka));
                }
            });
        }
    }// end class TimeUpDoun

    public void vklychitPorcVydox(){

        tgPVydox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    if (inTimepda < 15) {
                        inPorcVydox = 3;
                        tgPVydox.setTextOn("Включается при  ПДА больше 14 сек.!");
                    }
                    else {
                        inPorcVydox = 10;
                        tgPVydox.setTextOn("Включен");

                    }
                } else {
                    inPorcVydox = 3;

                }
            }

        });
    }





}//end AppCompatActivity